#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist, Point
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from math import atan2
from math import sqrt
from math import pi
from math import atan

# Starts a new node
rospy.init_node('avoider')
velocity_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

# SET UP VARIABLES

# Set up ranges
closeRange = 0.9
longRange = 1.5

# Robot clearnace width
robotWidth = 0.7

# Set up angles of areas
leftMax = 719
leftDiagClose = 652
# 180/pi is to convert from radians to degrees. 4 gets is from a 180 to 720 reference.
leftDiagFar = int((180/pi)*4*((pi/2)+atan((robotWidth/2)/closeRange)))
print ('leftDiagFar = ', leftDiagFar)
# the 90 is the center of what we are doing
rightDiagFar = int((180/pi)*4*((pi/2)-atan((robotWidth/2)/closeRange)))
print ('rightDiagFar = ', rightDiagFar)
rightDiagClose = 68
rightMax = 0

# Set up the different areas and initialise them as having no obstacles.
frontCloseArea = [False, leftDiagFar, rightDiagFar, closeRange]


rightDiagCloseArea = [False, rightDiagFar, rightDiagClose, closeRange]

rightMaxCloseArea = [False, rightDiagClose, rightMax, longRange]


leftDiagCloseArea = [False, leftDiagClose, leftDiagFar, closeRange]


leftMaxCloseArea = [False, leftMax, leftDiagClose, longRange]


# initialse an empty list of 720 slots (this is for the laser)
distances = [None]*720

# set up message types
vel_msg = Twist()
goal = Point()

# set up goal location

X_goal = 0
Y_goal = 0


setCoordinates = False

# variables of current location
x = 0
y = 0
theta = 0


# SET UP METHODES

# Given a certain area we check for objects (we might look at only half the values in an area if we need to save time .. this is a potential change)


def objExsist(area):

    # 0 = boolean of object exsiting   1= left of area   2 = right of area   3 = range
    for i in range(area[2], area[1]):
        if distances[i] <= area[3] and distances[i] > 0.1:
            area[0] = True


# This is where we call all the areas we wish to check
def areaObjectFinder():
    # print('started object detection')
    objExsist(frontCloseArea)

    objExsist(leftMaxCloseArea)
    objExsist(leftDiagCloseArea)

    objExsist(rightMaxCloseArea)
    objExsist(rightDiagCloseArea)
    # print('finished object detection')


# reset areas to empty
def resetAreaBoolean():
    frontCloseArea[0] = False

    rightDiagCloseArea[0] = False

    rightMaxCloseArea[0] = False

    leftDiagCloseArea[0] = False

    leftMaxCloseArea[0] = False


def newOdom(msg):

    global x
    global y
    global theta

    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    rot_q = msg.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion(
        [rot_q.x, rot_q.y, rot_q.z, rot_q.w])


# write msg.range into our list of distances for use in the rest of the code
def LaserReadings(msg):
    # print('finished with laser LaserReadings')
    global distances

    for i in range(0, 719):
        distances[i] = msg.ranges[i]

# we ask if the robot is pointing in direction of the goal.
# when it's pointing in the direction of goal it goes forward


def p2pWriter():
    inc_x = X_goal - x
    inc_y = y - Y_goal

    angle_to_goal = atan2(inc_y, inc_x)

    goalAngleInlasers = (720/pi)*(1*pi/(2)+abs(angle_to_goal + theta))

    # we check if we are at the goal
    if sqrt(inc_y*inc_y + inc_x*inc_x) <= 0.3:
        global setCoordinates
        setCoordinates = False
        print ('weve arrived at the goal lads')
        vel_msg.linear.x = 0.0
        vel_msg.angular.z = 0.0
    # we check we aren't driving towards an obstacle whilst trying to go towards our goal (prevents spasams)
    else:
        default = True
        # if you want to go forward and there's something there
        if frontCloseArea[0] and frontCloseArea[1] >= goalAngleInlasers >= frontCloseArea[2]:
            print (' we are gonna hit a wall capta" ')
            # set forward speed
            vel_msg.linear.x = 0

            # set truning speed
            vel_msg.angular.z = -0.4  # turn right

            default = False
            global default
        if rightDiagCloseArea[0] and rightDiagCloseArea[1] >= goalAngleInlasers >= rightDiagCloseArea[2]:
            print (' rightDiagObj ')
            # set forward speed
            vel_msg.linear.x = 0.2

            # set truning speed
            vel_msg.angular.z = 0.5  # turn left
            default = False
            global default
        if rightMaxCloseArea[0] and rightMaxCloseArea[1] >= goalAngleInlasers >= rightMaxCloseArea[2]:
            print (' rightMaxCloseArea ')
            # set forward speed
            vel_msg.linear.x = 0.4

            # set truning speed
            vel_msg.angular.z = 0.0  # turn left
            default = False
            global default
        if leftDiagCloseArea[0] and leftDiagCloseArea[1] >= goalAngleInlasers >= leftDiagCloseArea[2]:
            print (' leftDiagCloseArea ')
            # set forward speed
            vel_msg.linear.x = 0.2

            # set truning speed
            vel_msg.angular.z = -0.5  # turn right
            default = False
            global default
        if leftMaxCloseArea[0] and leftMaxCloseArea[1] >= goalAngleInlasers >= leftMaxCloseArea[2]:
            print (' leftMaxCloseArea ')
            # set forward speed
            vel_msg.linear.x = 0.4

            # set truning speed
            vel_msg.angular.z = 0.0  # turn right
            default = False
            global default
        if default is True:

            print ('the X,Y coordiante you picked is:', X_goal, Y_goal)
            if abs(angle_to_goal + theta) > 0.2 and (angle_to_goal + theta) <= 0:
                print('angle to goal is', (angle_to_goal+theta))
                vel_msg.linear.x = 0.2
                vel_msg.angular.z = 0.4  # turns left
                # print('we are going to the left', (theta))
            elif abs(angle_to_goal + theta) > 0.2 and (angle_to_goal + theta) > 0:
                print('angle to goal is', (angle_to_goal+theta))
                vel_msg.linear.x = 0.2
                vel_msg.angular.z = -0.4  # turns right
                # print('we are going to the right', (theta))
            else:
                print('correct heading, going straight. The angle to goal should be: 0.1 > ',
                      (angle_to_goal+theta))
                vel_msg.linear.x = 0.4
                vel_msg.angular.z = 0.0

    velocity_publisher.publish(vel_msg)

# Define how the robot should react (this may be added to seperate class later on)


def velocityWritter():
    # we check if objects exsist in areas
    areaObjectFinder()

    # we are saying that vel_message is a Twist() object.. I think

    # The robot behavior is defined here, to avoid writting too much code we branch from a situation where all areas are occupied to a situations
    # where the areas aren't occupied.  This means we only encode Areas that are occupied (we don't encode areas that are free of obstacles)

    # if in corner/deadend, pivot at current position to turn around
    if frontCloseArea[0] is True and leftDiagCloseArea[0] is True and leftMaxCloseArea[0] is True and rightDiagCloseArea[0] is True and rightMaxCloseArea[0] is True:
        print (' in corner ')
        # set forward speed
        vel_msg.linear.x = 0

        # set truning speed
        vel_msg.angular.z = -0.4  # turn right

    # if you are stuck in a leftwards corner
    elif frontCloseArea[0] is True and leftDiagCloseArea[0] is True and leftMaxCloseArea[0] is True:
        print (' in leftwards corner ')
        # set forward speed
        vel_msg.linear.x = 0

        # set truning speed
        vel_msg.angular.z = -0.4

    # if stuck in a rightwards corner
    elif frontCloseArea[0] is True and rightDiagCloseArea[0] is True and rightMaxCloseArea[0] is True:
        print (' in rightwards corner ')
        # set forward speed
        vel_msg.linear.x = 0

        # set truning speed
        vel_msg.angular.z = 0.4  # turn left

    # default move forward
    else:
        p2pWriter()

    # This is the final message published to the the twist topic
    velocity_publisher.publish(vel_msg)
    # reset areas for next sweep
    resetAreaBoolean()


def userCooridnates():
    X_goal = int(input('Enter the X coordinate:  '))
    Y_goal = int(input('Enter the Y coordinate:  '))
    print('Printing type of input value')
    print ('the X,Y coordiante you picked is:', X_goal, Y_goal)
    global X_goal
    global Y_goal
    global setCoordinates
    setCoordinates = True


# the subscribers
rospy.Subscriber('kobuki/laser/scan', LaserScan, LaserReadings)
sub = rospy.Subscriber('odom', Odometry, newOdom)
while not rospy.is_shutdown():
    rospy.sleep(0.1)
    if setCoordinates is False:
        userCooridnates()
    velocityWritter()

    print(' ')
    print(' ')
