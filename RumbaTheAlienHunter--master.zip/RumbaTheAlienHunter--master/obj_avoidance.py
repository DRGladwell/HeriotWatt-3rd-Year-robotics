#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

    
# Starts a new node
rospy.init_node('avoider')
velocity_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
FRONT_dist  = 420
LEFT_dist   = 420
RIGHT_dist  = 420
LEFTdiag_dist= 420
RIGHTdiag_dist = 420

# define message to be written
def LaserReadings(msg):
   
    global LEFT_dist
    global LEFTdiag_dist
    
    global FRONT_dist
    
    global RIGHTdiag_dist
    global RIGHT_dist
    
    
    
    LEFT_dist = msg.ranges[719] 
    LEFTdiag_dist = msg.ranges[500]
    
    FRONT_dist = msg.ranges[360]
    
    RIGHTdiag_dist = msg.ranges[220]
    RIGHT_dist = msg.ranges[0]
 
def velocityWritter():
    
    vel_msg = Twist()
    
    middleDist = FRONT_dist
    leftDist = LEFT_dist
    rightDist = RIGHT_dist
    leftDiagDist = LEFTdiag_dist
    rightDiagDist = RIGHTdiag_dist
    
    print('my front distance is:', middleDist)
    print('my left distance is:', leftDist)
    print('my right distance is:', rightDist)
    print('##################################')
    print('##################################')
    
    
    # Sharp turn righ if in corner
    if middleDist < 0.7 and leftDiagDist < 1 :
         # set forward speed    
        vel_msg.linear.x = 0
    
        # set truning speed 
        vel_msg.angular.z = -0.7
    
    # Sharp turn righ if in corner
    elif middleDist < 0.7 and rightDiagDist < 1 :
         # set forward speed    
        vel_msg.linear.x = 0
    
        # set truning speed 
        vel_msg.angular.z = 0.7
    
    
    
    # Sharp turn righ if in corner
    elif middleDist < 0.7 and leftDist < 1 :
         # set forward speed    
        vel_msg.linear.x = 0
    
        # set truning speed 
        vel_msg.angular.z = -0.7
        
    # Sharp turn left if in corner    
    elif middleDist < 0.7 and rightDist < 1 :
         # set forward speed    
        vel_msg.linear.x = 0
    
        # set truning speed 
        vel_msg.angular.z = 0.7
        
    #what to do if theres an object that's infornt of it
    elif middleDist < 0.7 :
         # set forward speed    
        vel_msg.linear.x = 0
    
        # set truning speed 
        vel_msg.angular.z = -0.7
        
    #default move forward  
    else:
        # set forward speed    
        vel_msg.linear.x = 1
    
        # set truning speed 
        vel_msg.angular.z = 0

    velocity_publisher.publish(vel_msg)
    


   
while not rospy.is_shutdown():
    rospy.sleep(1.)
    velocityWritter()
    rospy.Subscriber('kobuki/laser/scan',LaserScan,LaserReadings)
   