#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist, Point
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from math import atan2

# Starts a new node
rospy.init_node('avoider')
velocity_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

# SET UP VARIABLES

# Set up angles of areas
leftMax = 719
leftDiagClose = 484
leftDiagFar = 427
rightDiagFar = 293
rightDiagClose = 236
rightMax = 0

# Set up ranges
closeRange = 0.5
farRange = 1

# Set up the different areas and initialise them as having no obstacles.
frontCloseArea = [False, leftDiagClose, rightDiagClose, closeRange]
frontFarArea = [False, leftDiagFar, rightDiagFar, farRange]


rightDiagCloseArea = [False, rightDiagClose, rightDiagFar, closeRange]
rightDiagFarArea = [False, rightDiagClose, rightDiagFar, farRange]

rightMaxCloseArea = [False, rightDiagFar, rightMax, closeRange]
rightMaxFarArea = [False, rightDiagFar, rightMax, farRange]


leftDiagCloseArea = [False, leftDiagClose, leftDiagFar, closeRange]
leftDiagFarArea = [False, leftDiagClose, leftDiagFar, farRange]

leftMaxCloseArea = [False, leftDiagFar, leftMax, closeRange]
leftMaxFarArea = [False, leftDiagFar, leftMax, farRange]


# initialse an empty list of 720 slots (this is for the laser)
distances = [None]*720

# set up message types
vel_msg = Twist()
goal = Point()

# set up goal location

goal.x = -6
goal.y = -2

# variables of current location
x = 0
y = 0
theta = 0
# SET UP METHODES

# Given a certain area we check for objects (we might look at only half the values in an area if we need to save time .. this is a potential change)


def objExsist(area):

    # 0 = boolean of object exsiting   1= left of area   2 = right of area   3 = range
    for i in range(area[2], area[1]):
        if distances[i] <= area[3]:
            area[0] = True


# This is where we call all the areas we wish to check
def areaObjectFinder():
    ##print('started object detection')
    objExsist(frontCloseArea)
    objExsist(frontFarArea)

    objExsist(leftMaxCloseArea)
    objExsist(leftMaxFarArea)
    objExsist(leftDiagCloseArea)
    objExsist(leftDiagFarArea)

    objExsist(rightMaxCloseArea)
    objExsist(rightMaxFarArea)
    objExsist(rightDiagCloseArea)
    objExsist(rightDiagFarArea)
    ##print('finished object detection')


# reset areas to empty
def resetAreaBoolean():
    frontCloseArea[0] = False
    frontFarArea[0] = False

    rightDiagCloseArea[0] = False
    rightDiagFarArea[0] = False

    rightMaxCloseArea[0] = False
    rightMaxFarArea[0] = False

    leftDiagCloseArea[0] = False
    leftDiagFarArea[0] = False

    leftMaxCloseArea[0] = False
    leftMaxFarArea[0] = False


def newOdom(msg):

    global x
    global y
    global theta

    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    rot_q = msg.pose.pose.orientation
    (roll, pitch, theta) = euler_from_quaternion(
        [rot_q.x, rot_q.y, rot_q.z, rot_q.w])


# write msg.range into our list of distances for use in the rest of the code
def LaserReadings(msg):
    ##print('finished with laser LaserReadings')
    global distances

    for i in range(0, 719):
        distances[i] = msg.ranges[i]

# we ask if the robot is pointing in direction of the goal.
# when it's pointing in the direction of goal it goes forward


def p2pWriter():
    print('we are in p2p')
    inc_x = goal.x - x
    inc_y = goal.y - y

    angle_to_goal = atan2(inc_y, inc_x)
    if abs(angle_to_goal - theta) > 0.1:
        print('angle to goal is', abs(angle_to_goal-theta))
        vel_msg.linear.x = 0.0
        vel_msg.angular.z = 0.3
    else:
        vel_msg.linear.x = 0.5
        vel_msg.angular.z = 0.0

    velocity_publisher.publish(vel_msg)
# Define how the robot should react (this may be added to seperate class later on)


def velocityWritter():
    # we check if objects exsist in areas
    areaObjectFinder()

    print('##### LOOKING IN FRONT CLOSE, IS OBJECT THERE ?:',
          frontCloseArea[0])
    print('##### LOOKING IN FRONT FAR, IS OBJECT THERE ?:',    frontFarArea[0])

    # we are saying that vel_message is a Twist() object.. I think

    # The robot behavior is defined here, to avoid writting too much code we branch from a situation where all areas are occupied to a situations
    # where the areas aren't occupied.  This means we only encode Areas that are occupied (we don't encode areas that are free of obstacles)

    # if in corner/deadend, pivot at current position to turn around
    if (frontCloseArea[0] == True or frontFarArea[0] == True) and (leftDiagCloseArea[0] == True or leftDiagFarArea[0] == True) and (leftMaxCloseArea[0] == True or leftDiagFarArea[0] == True) and (rightDiagCloseArea[0] == True or rightDiagFarArea[0] == True) and (rightMaxCloseArea[0] == True or rightMaxFarArea[0] == True):
         # set forward speed
        vel_msg.linear.x = 0

        # set truning speed
        vel_msg.angular.z = -0.7  # turn right

    # if you are stuck in a leftwards corner
    elif (frontCloseArea[0] == True or frontFarArea[0] == True) and (leftDiagCloseArea[0] == True or leftDiagFarArea[0] == True) and (leftMaxCloseArea[0] == True or leftDiagFarArea[0] == True):
         # set forward speed
        vel_msg.linear.x = 0

        # set truning speed
        vel_msg.angular.z = -0.7

    # if stuck in a rightwards corner
    elif (frontCloseArea[0] == True or frontFarArea[0] == True) and (rightDiagCloseArea[0] == True or rightDiagFarArea[0] == True) and (rightMaxCloseArea[0] == True or rightMaxFarArea[0] == True):
         # set forward speed
        vel_msg.linear.x = 0

        # set truning speed
        vel_msg.angular.z = 0.7  # turn left

    # what to do if theres an object that's infornt of it (it turns right)
    elif frontCloseArea[0] == True:
        # set forward speed
        vel_msg.linear.x = 0

        # set truning speed
        vel_msg.angular.z = -0.7  # turn right

    # default move forward
    else:
        # set forward speed
        vel_msg.linear.x = 1

        # set truning speed
        vel_msg.angular.z = 0

    # This is the final message published to the the twist topic
    velocity_publisher.publish(vel_msg)
    # reset areas for next sweep
    resetAreaBoolean()


# the subscribers
rospy.Subscriber('kobuki/laser/scan', LaserScan, LaserReadings)
sub = rospy.Subscriber('odom', Odometry, newOdom)
while not rospy.is_shutdown():
    rospy.sleep(0.1)
    # p2pWriter()
    velocityWritter()

    print('############################################')
    print('############################################')
